﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ChaitAppClient;

namespace ChaitPresClient.Controller
{
    // Chait客户端状态管理类
    class ChaitManager
    {
        #region Instance
        private static ChaitManager instance;
        public static ChaitManager Instance
        {
            get
            {
                if (instance == null)
                    instance = new ChaitManager();
                return instance;
            }
        }
        private ChaitManager()
        {
        }
        #endregion

        #region Variables
        public ChaitNet ChaitNet;
        public ChaitChat ChaitChat;
        public ChaitPlayer ChaitPlayer;
        public ChaitGame ChaitGame;
        #endregion

        // Chait客户端状态清单
        // ----------------------------------------------------------------------------------------------------------------------------
        //  名称          网络连接管理        世界聊天收发       游戏聊天收发       好友聊天收发        交换玩家数据      交换游戏数据
        // ----------------------------------------------------------------------------------------------------------------------------
        //  初始化前             N                 N                    N                   N                  N                 N
        //  初始化完成           P                 N                    N                   N                  N                 N
        //  联机                 Y                 Y                    N                   Y                  Y                 N
        //  游戏中               Y                 Y                    Y                   Y                  Y                 Y

        public void Initial()
        {
            // 创建子控制器
            ChaitNet = new ChaitNet();
            ChaitChat = new ChaitChat();
            ChaitPlayer = new ChaitPlayer();

            // 设置回调
            ChaitClient.Instance.OnServerStopEvent += ChaitNet.OnServerStopHandler;
            ChaitClient.Instance.OnKickEvent += ChaitNet.OnKickHandler;
            ChaitClient.Instance.OnNeckExistEvent += ChaitNet.OnNeckExistHandler;
            ChaitClient.Instance.OnDisconnectEvent += ChaitNet.OnDisconnectHandler;

            ChaitClient.Instance.OnJoinEvent += ChaitChat.OnJoinHandler;
            ChaitClient.Instance.OnQuitEvent += ChaitChat.OnQuitHandler;
            ChaitClient.Instance.OnNeckListEvent += ChaitChat.OnNeckListHandler;
            ChaitClient.Instance.OnLobbyChatEvent += ChaitChat.OnLobbyChatHandler;
            ChaitClient.Instance.OnChatEvent += ChaitChat.OnChatHandler;

            ChaitClient.Instance.OnJoinGroupEvent += onJoinGroupHandler;
            ChaitClient.Instance.OnQuitGroupEvent += onQuitGroupHandler;
            ChaitClient.Instance.OnGroupListEvent += onGroupListHandler;
            ChaitClient.Instance.OnYellEvent += onYellHandler;
            ChaitClient.Instance.OnErrorEvent += onChatErrorHandler;
        }

    }
}
