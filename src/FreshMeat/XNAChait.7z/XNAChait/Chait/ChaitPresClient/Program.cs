﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ChaitAppClient;

namespace ChaitPresClient
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            // 初始化平台客户端模块
            ChaitClient.Instance.Initial();

            // 启动窗体
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LobbyForm());
        }
    }
}
