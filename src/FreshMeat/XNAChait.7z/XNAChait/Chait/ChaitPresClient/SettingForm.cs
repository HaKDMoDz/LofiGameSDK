﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using ChaitAppClient;

namespace ChaitPresClient
{
    public partial class SettingForm : Form
    {
        public SettingForm()
        {
            InitializeComponent();
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == "连接")
            {
                IPAddress serverIP;
                if (!IPAddress.TryParse(cbb_serverIP.Text.Trim(), out serverIP))
                {
                    MessageBox.Show("请输入一个合法的服务器IP地址");
                    return;
                }
                int serverPort;
                if (!int.TryParse(tb_serverPort.Text.Trim(), out serverPort))
                {
                    MessageBox.Show("请输入一个合法的服务器端口");
                    return;
                }
                IPAddress localIP;
                if (!IPAddress.TryParse(cbb_localIP.Text.Trim(), out localIP))
                {
                    MessageBox.Show("请输入一个合法的本地IP");
                    return;
                }
                String neckName = tb_neckName.Text.Trim();
                if (neckName == "")
                {
                    MessageBox.Show("请输入昵称");
                    return;
                }
                try
                {
                    ChaitClient.Instance.Join(serverIP, serverPort, neckName, localIP);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                // 获取在线好友列表
                //ChaitClient.Instance.NeckList(); // TODO 问题：无法同时获取两个列表，后一条请求信息丢失
                // 获取群组列表
                ChaitClient.Instance.GroupList();

                btn.Text = "断开";
            }
            else
            {
                try
                {
                    ChaitClient.Instance.Quit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                btn.Text = "连接";
            }
        }
    }
}
