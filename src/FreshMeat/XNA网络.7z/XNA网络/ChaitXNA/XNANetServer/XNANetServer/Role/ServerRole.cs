﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XNANetServer.Role
{
    class ServerRole
    {
        public const int Speed = 80;    // 80 pixel/second

        public String Name;
        public int X;
        public int Y;
        public int TargetX;
        public int TargetY;

        public void Update()
        {
            // 计算方向
            

            // 产生位移
            int add

            // 更新位置

            // 广播位置
        }
    }
}
